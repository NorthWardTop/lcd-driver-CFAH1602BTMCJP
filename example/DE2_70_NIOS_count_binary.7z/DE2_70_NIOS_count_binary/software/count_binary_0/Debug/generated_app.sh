#! /bin/sh
#
 
# DO NOT MODIFY THIS FILE
#
#   Changing this file will have subtle consequences
#   which will almost certainly lead to a nonfunctioning
#   system. If you do modify this file, be aware that your
#   changes will be overwritten and lost when this file
#   is generated again.
#
# DO NOT MODIFY THIS FILE
 
SYSTEM_CONFIG_DIR=/cygdrive/d/0Clare/DE2-70/Q80/DE2_70_NIOS_count_binary/software/count_binary_0_syslib/Debug
